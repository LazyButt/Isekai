# Motore Personalità — Skeleton

Struttura modulare di base per il gioco a scelte. Ogni file fa una cosa sola,
così è facile estenderlo man mano che aggiungiamo funzionalità.

## File

- `traits.js` — tratti base, profilo persistente, tratto dominante, inventario, equipaggiamento
- `emotions.js` — catalogo emozione → delta di tratti
- `combat.js` — statistiche di combattimento derivate dai tratti (mai assegnabili), risoluzione battaglia
- `story-engine.js` — opzioni di scena, branching narrativo, timer per la scelta nascosta
- `run.js` — una run = sequenza fissa di stage ("una vita"), tratto dominante locale alla run
- `items.js` — drop casuali a fine run, rarità, cosmetici a slot
- `magic.js` — affinità elementali sbloccate da soglie di tratto lifetime
- `storage.js` — salvataggio profilo (localStorage, da sostituire con backend se serve multi-dispositivo)
- `demo.html` — lobby + run interattiva che collega tutto

## Come provarlo

I file usano i moduli ES (`import`/`export`), quindi **non funziona aprendo
`demo.html` con doppio click** (i browser bloccano gli import via `file://`).
Serve un server locale, ad esempio:

```bash
cd personality-game-engine
python3 -m http.server 8000
```

poi apri `http://localhost:8000/demo.html`.

(Oppure: estensione "Live Server" di VS Code, se la usi già per Guild Board.)

## Architettura: lobby + run

Il gioco non è una progressione lineare a stage. È strutturato come:

- **Lobby**: schermata fissa fuori dalla run. Mostra il profilo lifetime
  (sempre persistente, non si azzera mai), l'aspetto cosmetico attuale e
  l'inventario di oggetti raccolti. Da qui si avvia una nuova run.
- **Run**: una sequenza FISSA di stage (`RUN_STAGES` in demo.html — nella
  demo: scena → battaglia → scena), che rappresenta "una vita". Ogni run
  parte dalle statistiche già accumulate nelle run precedenti: più run fai,
  più il profilo lifetime diventa accurato, ma ogni singola run resta
  breve e leggera da giocare.
- **Fine run**: si calcola il tratto dominante DI QUESTA RUN nello
  specifico (`trattoDominanteRun` in `run.js` — usa solo il delta
  accumulato durante la run, non il profilo lifetime), e in base a quello
  si genera un drop casuale a tema (`generaDrop` in `items.js`). L'oggetto
  entra nell'inventario persistente e resta visibile in lobby.

Per allungare una run basta aggiungere stage all'array `RUN_STAGES`.

## Drop, rarità e cosmetici

`generaDrop` tira prima una **rarità** (pesata: comune 60%, raro 30%,
epico 9%, leggendario 1% — modificabile in `RARITY_WEIGHTS`), poi pesca un
oggetto di quella rarità dal pool del tratto dominante della run. Se quel
tratto non ha nulla esattamente a quella rarità, cerca la rarità più
vicina disponibile (utile per "inerzia", che ha solo raro/leggendario).

Ogni oggetto ha:
- `slot`: `testa` / `corpo` / `accessorio` (equipaggiabile, puramente
  cosmetico — non incide su tratti o statistiche) oppure `cimelio`
  (trofeo narrativo, non equipaggiabile, riservato perlopiù alla rarità
  leggendaria)

In lobby: l'inventario mostra colore/etichetta di rarità, e per i
cosmetici un bottone Equipaggia/Rimuovi. Il riepilogo in cima alla lobby
mostra l'aspetto attualmente indossato (`profile.equipaggiamento`).

Per aggiungere nuovi cosmetici basta aggiungere voci a `ITEM_POOL` in
`items.js`, seguendo la struttura `tratto → rarità → [oggetti]`.

## Il tratto nascosto: "inerzia"

Easter egg non spiegato al giocatore. Si attiva solo quando una scena
`importante: true` con `timerSeconds` scade senza che il giocatore scelga
nulla. Pensato per catturare due cose diverse con lo stesso segnale:
difficoltà a reagire quando impreparati, oppure indifferenza verso ciò
che sta succedendo — il gioco non distingue le due letture, resta ambiguo
di proposito.

Regole:
- Non compare mai tra le barre dei tratti in UI (`getVisibleTraits` la
  esclude sempre)
- Conta comunque per il tratto dominante (sia lifetime che di singola run)
  e per il branching narrativo (vedi il branch `inerzia` nei checkpoint
  d'esempio)
- Ha un pool di drop tutto suo, spostato verso le rarità alte (niente
  "comune": resta sempre un po' fuori posto rispetto agli altri tratti)
- Ogni scena può personalizzare il proprio delta/testo di inazione via
  `scene.inazione`, altrimenti usa un default generico

Per aggiungere altre scene importanti: `validaScenaImportante(scene)` in
`story-engine.js` avvisa in console se manca il timer o se ci sono meno
di 2 opzioni visibili.

## Magia: affinità sbloccate dai tratti

`magic.js` collega ogni tratto visibile a un elemento. Quando un tratto
**lifetime** del profilo supera `SOGLIA_SBLOCCO_MAGIA` (default 10),
l'affinità corrispondente si sblocca — e resta sbloccata per sempre, dato
che il profilo non si azzera mai tra le run.

| Tratto | Elemento |
|---|---|
| coraggio | Fuoco |
| cautela | Acqua |
| empatia | Luce |
| pragmatismo | Terra |
| astuzia | Ombra |
| leadership | Fulmine |
| impulsivita | Vento |
| riflessione | Ghiaccio |
| inerzia *(nascosto)* | Vuoto |

Punti chiave:
- **Non è esclusivo**: più tratti possono superare la soglia insieme, e
  la persona ha più affinità contemporaneamente (realistico: nessuno è
  un solo elemento)
- **Cresce oltre lo sblocco**: il danno magico (`calcolaDannoMagico`)
  scala con quanto il tratto supera la soglia, non è un semplice on/off
- **"Vuoto" non è mai uno slot bloccato visibile**: compare nella
  griglia delle affinità SOLO se viene davvero sbloccato (stessa logica
  di `getVisibleTraits` per i tratti nascosti)
- **Ha un effetto reale**: `risolviBattaglia` in `combat.js` somma danno
  fisico + danno magico, quindi sbloccare un'affinità conta davvero in
  battaglia, non è solo estetico

Per testare velocemente senza giocare decine di run: abbassa
temporaneamente `SOGLIA_SBLOCCO_MAGIA` in `magic.js` (es. a 3).

## Punti aperti / facili da estendere

- Soglia del tratto dominante è fissa (5 per il branching narrativo, 3 per
  il dominante di run), parametrizzabile per scena/run
- Battaglia è volutamente semplice (un solo scambio): da espandere con
  turni, HP del giocatore, più nemici
- I rami narrativi (`checkpointPreview`) per ora mostrano solo un'anteprima
  testuale: in un gioco completo dovrebbero caricare contenuti diversi per
  lo stage successivo, non solo cambiare il testo mostrato
- Nessun limite/condizione di "game over" all'interno di una run: anche
  perdendo una battaglia la run prosegue fino in fondo (vinta o persa, il
  personaggio cresce comunque)
- L'equipaggiamento è puramente cosmetico per ora: se in futuro vuoi che
  influenzi anche le statistiche, andrebbe aggiunto in `combat.js`
