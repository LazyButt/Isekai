// items.js
// Drop casuali a fine run, tematizzati sul tratto dominante DELLA RUN
// appena conclusa (non del profilo lifetime). Ogni oggetto ha una rarità
// e, se cosmetico, uno slot equipaggiabile (testa/corpo/accessorio).
// Gli oggetti di slot "cimelio" sono trofei narrativi non equipaggiabili
// (storicamente riservati alle rarità più alte).

export const RARITY_WEIGHTS = {
  comune: 60,
  raro: 30,
  epico: 9,
  leggendario: 1
};

export const RARITY_INFO = {
  comune: { label: 'Comune', colore: '#9a9a9a' },
  raro: { label: 'Raro', colore: '#4a86e8' },
  epico: { label: 'Epico', colore: '#a479e2' },
  leggendario: { label: 'Leggendario', colore: '#c9a227' }
};

const RARITY_ORDER = ['comune', 'raro', 'epico', 'leggendario'];

export const ITEM_POOL = {
  coraggio: {
    comune: [{ id: 'corpetto_intaccato', nome: 'Corpetto Intaccato', slot: 'corpo', desc: 'Porta i segni di scontri già vinti.' }],
    raro: [{ id: 'mantello_temerario', nome: 'Mantello del Temerario', slot: 'accessorio', desc: 'Non si è mai voltato per scappare.' }],
    epico: [{ id: 'elmo_ariete', nome: "Elmo dell'Ariete", slot: 'testa', desc: 'Pesante, vistoso, inconfondibile.' }],
    leggendario: [{ id: 'spada_mai_rinfoderata', nome: 'Spada Mai Rinfoderata', slot: 'cimelio', desc: 'Si dice non abbia mai conosciuto la pace.' }]
  },
  cautela: {
    comune: [{ id: 'giubba_rinforzata', nome: 'Giubba Rinforzata', slot: 'corpo', desc: 'Un passo indietro, sempre pronto.' }],
    raro: [{ id: 'bussola_consumata', nome: 'Bussola Consumata', slot: 'accessorio', desc: 'Hai sempre controllato due volte la strada.' }],
    epico: [{ id: 'cappuccio_ombra', nome: "Cappuccio dell'Ombra", slot: 'testa', desc: 'Per non farsi notare mai per primi.' }],
    leggendario: [{ id: 'chiave_porta_mai_aperta', nome: 'Chiave di una Porta Mai Aperta', slot: 'cimelio', desc: 'Forse era meglio così.' }]
  },
  empatia: {
    comune: [{ id: 'veste_guaritore', nome: 'Veste del Guaritore', slot: 'corpo', desc: 'Logora, ma sempre pulita per chi ne ha bisogno.' }],
    raro: [{ id: 'lettera_sigillata', nome: 'Lettera Sigillata', slot: 'accessorio', desc: "Scritta per qualcuno che hai aiutato, mai spedita." }],
    epico: [{ id: 'corona_spine_dolci', nome: 'Corona di Spine Dolci', slot: 'testa', desc: 'Un peso portato per qualcun altro.' }],
    leggendario: [{ id: 'ultimo_respiro_condiviso', nome: 'Ultimo Respiro Condiviso', slot: 'cimelio', desc: 'Non ricordi più di chi fosse.' }]
  },
  pragmatismo: {
    comune: [{ id: 'grembiule_lavoro', nome: 'Grembiule da Lavoro', slot: 'corpo', desc: 'Funzionale, niente di superfluo.' }],
    raro: [{ id: 'taccuino_conti', nome: 'Taccuino dei Conti', slot: 'accessorio', desc: 'Ogni decisione, pesata fino in fondo.' }],
    epico: [{ id: 'lente_calcolo', nome: 'Lente del Calcolo', slot: 'testa', desc: 'Vede solo ciò che conviene vedere.' }],
    leggendario: [{ id: 'bilancia_senza_piatti', nome: 'Bilancia Senza Piatti', slot: 'cimelio', desc: 'Hai smesso di pesare anche te stesso.' }]
  },
  astuzia: {
    comune: [{ id: 'mantello_doppia_faccia', nome: 'Mantello a Doppia Faccia', slot: 'corpo', desc: 'Cambia colore a seconda di chi guarda.' }],
    raro: [{ id: 'chiave_senza_serratura', nome: 'Chiave Senza Serratura', slot: 'accessorio', desc: "L'hai presa comunque. Non si sa mai." }],
    epico: [{ id: 'maschera_mercante', nome: 'Maschera del Mercante', slot: 'testa', desc: 'Nessuno ha mai capito cosa pensassi davvero.' }],
    leggendario: [{ id: 'carta_segnata', nome: 'Carta Segnata', slot: 'cimelio', desc: 'Hai sempre saputo come sarebbe finita.' }]
  },
  leadership: {
    comune: [{ id: 'mantellina_stemma', nome: 'Mantellina con Stemma', slot: 'corpo', desc: 'Cucita da chi ti ha seguito.' }],
    raro: [{ id: 'stendardo_logoro', nome: 'Stendardo Logoro', slot: 'accessorio', desc: 'Altri ti hanno seguito fin qui.' }],
    epico: [{ id: 'diadema_comando', nome: 'Diadema del Comando', slot: 'testa', desc: 'Non l\'hai mai chiesto, ma te lo sei guadagnato.' }],
    leggendario: [{ id: 'voce_non_trema', nome: 'Voce Che Non Trema', slot: 'cimelio', desc: 'Hanno smesso di chiedersi se seguirti.' }]
  },
  impulsivita: {
    comune: [{ id: 'giacca_strappata', nome: 'Giacca Strappata', slot: 'corpo', desc: 'Non hai mai aspettato il momento giusto.' }],
    raro: [{ id: 'dado_consumato', nome: 'Dado Consumato', slot: 'accessorio', desc: "Hai deciso più spesso d'istinto che a mente fredda." }],
    epico: [{ id: 'cresta_piume_rosse', nome: 'Cresta di Piume Rosse', slot: 'testa', desc: 'Si vede arrivare prima ancora di sentirlo.' }],
    leggendario: [{ id: 'primo_passo_mai_ripensato', nome: 'Primo Passo Mai Ripensato', slot: 'cimelio', desc: 'Non hai mai voluto sapere cosa sarebbe successo a fermarti.' }]
  },
  riflessione: {
    comune: [{ id: 'mantello_grigio', nome: 'Mantello Grigio', slot: 'corpo', desc: "Niente che attiri l'attenzione mentre pensi." }],
    raro: [{ id: 'diario_macchiato', nome: 'Diario Macchiato', slot: 'accessorio', desc: 'Pagine piene di domande, poche risposte.' }],
    epico: [{ id: 'occhiali_studioso', nome: 'Occhiali da Studioso', slot: 'testa', desc: 'Per guardare meglio, anche quando fa male.' }],
    leggendario: [{ id: 'domanda_mai_risposta', nome: 'Domanda Mai Risposta', slot: 'cimelio', desc: "L'hai portata con te per tutta la vita." }]
  },
  equilibrato: {
    comune: [{ id: 'abito_neutro', nome: 'Abito Neutro', slot: 'corpo', desc: 'Né elegante né dimesso. Semplicemente adatto.' }],
    raro: [{ id: 'moneta_bifronte', nome: 'Moneta Bifronte', slot: 'accessorio', desc: 'Nessun lato prevale mai davvero, in questa vita.' }],
    epico: [{ id: 'velo_trasparente', nome: 'Velo Trasparente', slot: 'testa', desc: 'Lascia vedere tutto, senza svelare nulla.' }],
    leggendario: [{ id: 'bilancia_equilibrio_perfetto', nome: 'Bilancia in Equilibrio Perfetto', slot: 'cimelio', desc: 'Non si è mai inclinata, in nessuna direzione.' }]
  },
  // Tratto nascosto: pool deliberatamente più povero e spostato verso le
  // rarità alte. Non dovrebbe sembrare "normale" come gli altri.
  inerzia: {
    raro: [{ id: 'orologio_fermo', nome: 'Orologio Fermo', slot: 'cimelio', desc: 'Segna sempre la stessa ora. Non ricordi di averlo preso.' }],
    leggendario: [{ id: 'sedia_vuota', nome: 'Sedia Vuota', slot: 'cimelio', desc: 'Nessuno ricorda se tu ci fossi seduto, in questa vita.' }]
  }
};

function tiraRarita() {
  const totale = Object.values(RARITY_WEIGHTS).reduce((a, b) => a + b, 0);
  let r = Math.random() * totale;
  for (const [rarita, peso] of Object.entries(RARITY_WEIGHTS)) {
    if (r < peso) return rarita;
    r -= peso;
  }
  return 'comune';
}

/** Trova la rarità disponibile più vicina a quella tirata, per un dato tratto. */
function bucketPiuVicino(poolTratto, raritaIniziale) {
  const idx = RARITY_ORDER.indexOf(raritaIniziale);
  for (let distanza = 0; distanza < RARITY_ORDER.length; distanza++) {
    const su = RARITY_ORDER[idx + distanza];
    const giu = RARITY_ORDER[idx - distanza];
    if (su && poolTratto[su]?.length) return su;
    if (giu && poolTratto[giu]?.length) return giu;
  }
  return null;
}

/**
 * Genera un drop casuale in base al tratto dominante DI QUESTA RUN.
 * La rarità è tirata a parte (pesata) e poi si cerca l'oggetto più
 * vicino a quella rarità nel pool del tratto (utile per tratti come
 * "inerzia" che non hanno tutte le rarità). Ritorna null se il tratto
 * non ha alcun oggetto: non ogni vita lascia qualcosa dietro di sé.
 */
export function generaDrop(trattoDominanteRun) {
  const poolTratto = ITEM_POOL[trattoDominanteRun];
  if (!poolTratto) return null;

  const raritaTirata = tiraRarita();
  const rarita = bucketPiuVicino(poolTratto, raritaTirata);
  if (!rarita) return null;

  const bucket = poolTratto[rarita];
  const item = bucket[Math.floor(Math.random() * bucket.length)];
  return { ...item, rarita };
}
