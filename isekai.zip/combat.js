// combat.js
// Le statistiche di combattimento sono SEMPRE derivate dai tratti del
// profilo: non esiste alcuna interfaccia per assegnarle manualmente.
// Questo impedisce al giocatore di "ottimizzare" il personaggio invece
// di comportarsi in modo autentico.

import { calcolaDannoMagico } from './magic.js';

const COMBAT_WEIGHTS = {
  danno_fisico:       { coraggio: 1.5, impulsivita: 0.5 },
  critico_percentuale: { astuzia: 2 },
  cura:                { empatia: 1.5 },
  difesa:              { pragmatismo: 1.5, cautela: 0.5 },
  velocita:            { impulsivita: 1, riflessione: -0.3 },
  schivata_percentuale: { riflessione: 1.5, cautela: 0.5 }
};

export function calcolaStatistiche(traits) {
  const stats = {};
  for (const [stat, pesi] of Object.entries(COMBAT_WEIGHTS)) {
    let valore = 0;
    for (const [trait, peso] of Object.entries(pesi)) {
      valore += (traits[trait] || 0) * peso;
    }
    stats[stat] = Math.max(0, Math.round(valore * 10) / 10);
  }
  return stats;
}

// Delta di tratti applicati in base all'esito della battaglia.
// Vinta o persa, il personaggio cresce comunque: cambia solo cosa impara.
export const BATTLE_OUTCOME_DELTAS = {
  vittoria: { coraggio: 1 },
  sconfitta: { riflessione: 2, cautela: 1 }
};

/**
 * Risolve una battaglia molto semplificata: confronta danno_fisico +
 * danno magico (da affinità sbloccate) del giocatore con gli hp del
 * nemico, tenendo conto di critico e schivata.
 * Sostituibile con una logica di combattimento più complessa in futuro.
 */
export function risolviBattaglia(traits, nemico) {
  const stats = calcolaStatistiche(traits);
  const magia = calcolaDannoMagico(traits);
  const critico = Math.random() * 100 < stats.critico_percentuale;
  const dannoFisico = stats.danno_fisico * (critico ? 1.5 : 1);
  const dannoTotale = dannoFisico + magia.totale;

  const vittoria = dannoTotale >= nemico.hp;
  const esito = vittoria ? "vittoria" : "sconfitta";

  return {
    esito,
    dannoInflitto: Math.round(dannoTotale * 10) / 10,
    dannoFisico: Math.round(dannoFisico * 10) / 10,
    dannoMagico: magia.totale,
    critico,
    statsUsate: stats,
    delta: BATTLE_OUTCOME_DELTAS[esito]
  };
}
