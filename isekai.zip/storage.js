// storage.js
// Persistenza del profilo. Prototipo con localStorage: se in futuro
// servirà multi-dispositivo o multi-utente, va sostituito con un backend
// mantenendo la stessa interfaccia (salvaProfilo/caricaProfilo).

const STORAGE_KEY = "profilo_giocatore";

export function salvaProfilo(profile) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
}

export function caricaProfilo(creaProfiloVuoto) {
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : creaProfiloVuoto();
}

export function resetProfilo() {
  localStorage.removeItem(STORAGE_KEY);
}
