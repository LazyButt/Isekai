// emotions.js
// Catalogo fisso emozione -> delta di tratti.
// Le scene non inventano nuovi pesi: pescano da qui, eventualmente
// amplificando con un modificatore locale (scene_modifier).

export const EMOTION_TRAIT_MAP = {
  rabbia:     { coraggio: 1, impulsivita: 2 },
  paura:      { cautela: 2, coraggio: -1 },
  gioia:      { empatia: 1, leadership: 1 },
  tristezza:  { empatia: 2, riflessione: 1 },
  disgusto:   { pragmatismo: 1, empatia: -1 },
  sorpresa:   { astuzia: 1, impulsivita: 1 },
  curiosita:  { riflessione: 2, astuzia: 1 },
  fiducia:    { empatia: 2, leadership: 1 }
};

/**
 * Calcola il delta finale di un'emozione per una scena specifica,
 * sommando il catalogo base con eventuali modificatori locali.
 */
export function resolveEmotionDelta(emozione, sceneModifiers = {}) {
  const base = EMOTION_TRAIT_MAP[emozione] || {};
  const modifier = sceneModifiers[emozione] || {};
  const result = { ...base };
  for (const [trait, value] of Object.entries(modifier)) {
    result[trait] = (result[trait] || 0) + value;
  }
  return result;
}
