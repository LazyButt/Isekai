// magic.js
// Affinità magica = elemento sbloccato quando un tratto del profilo
// LIFETIME supera una soglia. Più tratti alti insieme sbloccano più
// affinità contemporaneamente: una persona non è mai un solo elemento.
//
// "vuoto" (legato al tratto nascosto "inerzia") non va MAI mostrata come
// slot "da sbloccare" in UI — resta coerente con la natura nascosta di
// quel tratto. Compare solo se e quando viene davvero sbloccata.

export const SOGLIA_SBLOCCO_MAGIA = 10;

export const MAGIC_AFFINITIES = {
  coraggio:    { id: 'fuoco',    nome: 'Fuoco',    colore: '#c0492f', desc: 'Aggressività ed energia che si fanno fiamma.' },
  cautela:     { id: 'acqua',    nome: 'Acqua',    colore: '#3c78d8', desc: 'Freddezza e prudenza che scorrono come corrente.' },
  empatia:     { id: 'luce',     nome: 'Luce',     colore: '#f2c960', desc: 'Calore umano che illumina chi le sta vicino.' },
  pragmatismo: { id: 'terra',    nome: 'Terra',    colore: '#7a5230', desc: 'Concretezza che si fa roccia solida.' },
  astuzia:     { id: 'ombra',    nome: 'Ombra',    colore: '#5c4a7a', desc: 'Inganno e percezione che vivono nel non-detto.' },
  leadership:  { id: 'fulmine',  nome: 'Fulmine',  colore: '#d6c23a', desc: 'Presenza che si impone come una scarica.' },
  impulsivita: { id: 'vento',    nome: 'Vento',    colore: '#7fc8c4', desc: "Velocità che non si lascia trattenere." },
  riflessione: { id: 'ghiaccio', nome: 'Ghiaccio', colore: '#8fd6e0', desc: 'Lucidità e controllo, immobili e taglienti.' },
  // Nascosta: vedi nota in cima al file.
  inerzia:     { id: 'vuoto',    nome: 'Vuoto',    colore: '#4a4640', desc: "L'assenza che si fa presenza. Nessuno sa spiegarla." }
};

export const HIDDEN_AFFINITY_TRAITS = ['inerzia'];

/** Tutte le affinità sbloccate ora, in base ai tratti lifetime del profilo. */
export function affinitaSbloccate(traits, soglia = SOGLIA_SBLOCCO_MAGIA) {
  const sbloccate = [];
  for (const [trait, valore] of Object.entries(traits)) {
    const affinita = MAGIC_AFFINITIES[trait];
    if (affinita && valore >= soglia) sbloccate.push({ ...affinita, trait, valore });
  }
  return sbloccate;
}

/**
 * Affinità da mostrare come "slot da sbloccare" (bloccati o sbloccati)
 * in UI: esclude quelle legate a tratti nascosti, che non devono mai
 * apparire come obiettivo dichiarato prima di essere ottenute.
 */
export function affinitaVisibiliComeSlot() {
  return Object.entries(MAGIC_AFFINITIES)
    .filter(([trait]) => !HIDDEN_AFFINITY_TRAITS.includes(trait))
    .map(([trait, aff]) => ({ ...aff, trait }));
}

/**
 * Danno magico totale derivato dalle affinità sbloccate. Non è on/off:
 * scala con quanto il tratto supera la soglia di sblocco, quindi la
 * magia continua a crescere anche dopo essere stata sbloccata.
 */
export function calcolaDannoMagico(traits, soglia = SOGLIA_SBLOCCO_MAGIA) {
  const dettagli = [];
  let totale = 0;
  for (const aff of affinitaSbloccate(traits, soglia)) {
    const danno = Math.round((aff.valore - soglia + 1) * 1.2 * 10) / 10;
    dettagli.push({ ...aff, danno });
    totale += danno;
  }
  return { totale: Math.round(totale * 10) / 10, dettagli };
}
