// traits.js
// Tratti base e gestione del profilo persistente del giocatore.
// Il profilo NON è mai modificabile direttamente dal giocatore:
// cresce solo come conseguenza di scelte, combattimenti ed esiti.

export const TRAIT_NAMES = [
  "coraggio",
  "cautela",
  "empatia",
  "pragmatismo",
  "astuzia",
  "leadership",
  "impulsivita",
  "riflessione"
];

// Tratti che esistono nel profilo ma non vengono MAI mostrati al giocatore
// nell'interfaccia. Si accumulano in silenzio, contano per il tratto
// dominante e per il branching come tutti gli altri.
//
// "inerzia": cresce quando il giocatore non sceglie nulla in una scena
// importante entro il tempo limite. Cattura sia il "non so come reagire,
// sono impreparato" sia il "non mi importa abbastanza per decidere" — un
// tratto volutamente ambiguo, mai spiegato in gioco.
export const HIDDEN_TRAIT_NAMES = ["inerzia"];

export function createEmptyProfile() {
  const traits = {};
  [...TRAIT_NAMES, ...HIDDEN_TRAIT_NAMES].forEach(t => { traits[t] = 0; });
  return {
    traits,
    playthroughs: 0, // numero di run completate
    endings: [],
    inventario: [], // oggetti ottenuti come drop di fine run
    equipaggiamento: { testa: null, corpo: null, accessorio: null }, // id oggetto per slot, o null
    history: [] // log di ogni evento che ha modificato i tratti (utile per analisi futura)
  };
}

/** Sottoinsieme di tratti da mostrare in UI: esclude quelli nascosti. */
export function getVisibleTraits(traits) {
  const visibili = {};
  for (const [nome, valore] of Object.entries(traits)) {
    if (!HIDDEN_TRAIT_NAMES.includes(nome)) visibili[nome] = valore;
  }
  return visibili;
}

/**
 * Applica un delta di tratti al profilo. Se il delta contiene un tratto
 * non previsto in TRAIT_NAMES, viene comunque accettato (estendibile).
 */
export function applyTraitDelta(profile, delta, sourceId = null) {
  for (const [trait, value] of Object.entries(delta)) {
    if (!(trait in profile.traits)) profile.traits[trait] = 0;
    profile.traits[trait] += value;
  }
  if (sourceId) {
    profile.history.push({ sourceId, delta, timestamp: Date.now() });
  }
  return profile;
}

/**
 * Tratto dominante: il più alto, ma solo se supera il secondo
 * di almeno `soglia` punti. Altrimenti "equilibrato" (anche questo
 * è un dato interessante sul giocatore).
 */
export function getDominantTrait(traits, soglia = 5) {
  const ordinati = Object.entries(traits).sort((a, b) => b[1] - a[1]);
  if (ordinati.length === 0) return null;
  if (ordinati.length === 1) return ordinati[0][0];
  const [top, secondo] = ordinati;
  return (top[1] - secondo[1] >= soglia) ? top[0] : "equilibrato";
}

export function getTopTraits(traits, n = 3) {
  return Object.entries(traits)
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([nome, valore]) => ({ nome, valore }));
}

export function registraFinale(profile, endingId) {
  profile.playthroughs += 1;
  profile.endings.push(endingId);
  return profile;
}

export function aggiungiOggetto(profile, item) {
  if (!item) return profile;
  if (!profile.inventario) profile.inventario = [];
  profile.inventario.push({ ...item, ottenutoAllaRun: profile.playthroughs, timestamp: Date.now() });
  return profile;
}

/**
 * Equipaggia un cosmetico nel suo slot (testa/corpo/accessorio).
 * Gli oggetti di slot "cimelio" non sono equipaggiabili: sono trofei
 * narrativi, non vestiario.
 */
export function equipaggia(profile, item) {
  if (!item || !item.slot || item.slot === 'cimelio') return profile;
  if (!profile.equipaggiamento) profile.equipaggiamento = {};
  profile.equipaggiamento[item.slot] = item.id;
  return profile;
}

export function rimuoviEquip(profile, slot) {
  if (profile.equipaggiamento) profile.equipaggiamento[slot] = null;
  return profile;
}
