// run.js
// Una "run" è una vita: una sequenza FISSA di stage (scena o battaglia)
// che il personaggio attraversa dall'inizio alla fine. Il profilo
// (tratti, inventario) è persistente e continua tra una run e l'altra —
// ogni nuova run parte dalle statistiche maturate in quelle precedenti.
//
// In più, ogni run calcola anche un proprio tratto dominante "locale"
// (solo i delta accumulati durante QUESTA run), usato per generare un
// drop a tema a fine vita. Così ogni run resta leggera/variabile, ma il
// personaggio nel suo complesso continua a crescere.

import { getDominantTrait } from './traits.js';

export function creaRun(stages, traitsAllInizio) {
  return {
    stages,
    stageIndex: 0,
    traitsAllInizio: { ...traitsAllInizio }, // snapshot per isolare il delta di questa run
    terminata: false
  };
}

export function stageCorrente(run) {
  return run.stages[run.stageIndex] || null;
}

export function avanzaStage(run) {
  run.stageIndex += 1;
  if (run.stageIndex >= run.stages.length) run.terminata = true;
  return run;
}

/**
 * Tratto dominante calcolato SOLO sul delta di questa run (tratti finali
 * meno tratti di inizio run), non sul profilo lifetime. Risponde alla
 * domanda "che tipo di vita è stata, questa run nello specifico?".
 * Soglia più bassa di quella usata per il branching narrativo, perché
 * una singola run ha meno scelte su cui costruire un pattern netto.
 */
export function trattoDominanteRun(run, traitsAllaFine, soglia = 3) {
  const delta = {};
  for (const trait of Object.keys(traitsAllaFine)) {
    delta[trait] = (traitsAllaFine[trait] || 0) - (run.traitsAllInizio[trait] || 0);
  }
  return getDominantTrait(delta, soglia);
}
