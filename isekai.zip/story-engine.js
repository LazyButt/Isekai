// story-engine.js
// Gestisce le opzioni emotive di una scena e il branching narrativo
// in base al tratto dominante accumulato nel profilo.

import { resolveEmotionDelta } from './emotions.js';
import { getDominantTrait } from './traits.js';

const DEFAULT_INERTIA_DELTA = { inerzia: 2 };

/**
 * Da una scena (con lista di emozioni valide) genera le opzioni
 * pronte da mostrare al giocatore, con testo e delta già calcolato.
 */
export function getSceneOptions(scene) {
  return scene.opzioni.map(emozione => ({
    emozione,
    testo: scene.testi?.[emozione] || emozione,
    delta: resolveEmotionDelta(emozione, scene.scene_modifier || {})
  }));
}

/**
 * Da un checkpoint con branch per tratto, risolve quale scena/capitolo
 * segue in base al tratto dominante attuale del profilo.
 */
export function resolveNextScene(checkpoint, traits, soglia = 5) {
  const dominante = getDominantTrait(traits, soglia);
  return checkpoint.branches[dominante] || checkpoint.branches.default;
}

/**
 * Avvia il timer di una scena importante. Se `onTimeout` non viene mai
 * cancellato (cioè il giocatore non sceglie in tempo), scatta la terza
 * opzione, mai mostrata in interfaccia: "non fare nulla".
 *
 * Una scena importante deve avere `importante: true`, `timerSeconds`
 * e almeno 2 opzioni visibili (vedi validaScenaImportante).
 *
 * Ritorna una funzione di cancellazione da chiamare quando il giocatore
 * sceglie un'opzione visibile in tempo.
 */
export function avviaTimerScena(scene, onTimeout) {
  if (!scene.importante || !scene.timerSeconds) return () => {};
  const delta = scene.inazione?.delta || DEFAULT_INERTIA_DELTA;
  const timeoutId = setTimeout(() => {
    onTimeout({
      sourceId: scene.id + ':inazione',
      delta,
      // Testo deliberatamente vago: il giocatore non deve capire che
      // si tratta di un evento tracciato, solo che il momento è passato.
      testo: scene.inazione?.testo || "Il momento passa. Non hai deciso."
    });
  }, scene.timerSeconds * 1000);
  return () => clearTimeout(timeoutId);
}

/**
 * Controllo "da autore": avvisa in console se una scena importante non
 * rispetta le regole minime (utile mentre si scrivono molte scene).
 */
export function validaScenaImportante(scene) {
  const problemi = [];
  if (!scene.opzioni || scene.opzioni.length < 2) {
    problemi.push(`Scena "${scene.id}": servono almeno 2 opzioni visibili.`);
  }
  if (!scene.timerSeconds) {
    problemi.push(`Scena "${scene.id}": manca timerSeconds per la scelta nascosta.`);
  }
  return problemi;
}
